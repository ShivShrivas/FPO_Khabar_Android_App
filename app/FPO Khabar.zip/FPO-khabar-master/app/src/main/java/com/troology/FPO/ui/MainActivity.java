package com.troology.FPO.ui;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.troology.FPO.R;
public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}